<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>GASS</title>
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <link rel="shortcut icon" href="<?php echo e(url('assets')); ?>/images/gass.png" />
      <link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/bootstrap.min.css">
      <link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/typography.css">
      <link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/style.css">
      <link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/responsive.css">
      <style>
         .iq-footer {
            width: calc(100vw - 260px) !important;
         }
      </style>
   </head>
   <body class="right-sidebar-close">
      <div class="wrapper">
         <?php echo $__env->make('template.section.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->make('template.section.top-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->yieldContent('content'); ?>
         <?php echo $__env->make('template.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <script src="<?php echo e(url('assets')); ?>/js/jquery.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/popper.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/bootstrap.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/jquery.appear.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/countdown.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/waypoints.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/jquery.counterup.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/wow.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/apexcharts.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/slick.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/select2.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/owl.carousel.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/jquery.magnific-popup.min.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/smooth-scrollbar.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/lottie.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/core.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/charts.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/animated.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/kelly.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/maps.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/worldLow.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/chart-custom.js"></script>
      <script src="<?php echo e(url('assets')); ?>/js/custom.js"></script>

      <script>
         
         $.ajaxSetup({
             headers: {
                 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
             }
         });
      </script>
      <?php echo $__env->yieldPushContent("script"); ?>
   </body>
</html>
<?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/template/base.blade.php ENDPATH**/ ?>