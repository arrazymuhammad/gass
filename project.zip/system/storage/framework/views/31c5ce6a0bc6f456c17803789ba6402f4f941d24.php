

<?php $__env->startSection('content'); ?>
<div id="content-page" class="content-page">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="iq-card">
					<div class="iq-card-body">
						<a href="<?php echo e(url('konsultasi')); ?>" class="btn btn-white"><i class="fa fa-chevron-left"></i></a> Kembali
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<?php $__currentLoopData = $list_dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-6">
				<div class="iq-card">
					<div class="iq-card-body profile-page p-0">
						<div class="profile-header-image">
							<div class="cover-container">
								<img src="<?php echo e(url('assets')); ?>/images/page-img/profile-bg1.jpg" alt="profile-bg" class="rounded img-fluid w-100">
							</div>
							<div class="profile-info p-4">
								<div class="user-detail">
									<div class="d-flex flex-wrap justify-content-between align-items-start">
										<div class="profile-detail d-flex">
											<div class="profile-img pr-4">
												<img src="<?php echo e(url($dokter->photo)); ?>" alt="profile-img" class="avatar-130 img-fluid" />
											</div>
											<div class="user-data-block">
												<h4 class=""><?php echo e($dokter->fullname); ?></h4>
												<p>Dokter Umum</p>
												<p><i class="fa fa-map-marker"></i> <?php echo e($dokter->alamat); ?></p>
											</div>
										</div>
									</div>
									<a href="<?php echo e(url('konsultasi/chat', $dokter->uuid)); ?>" class="btn btn-primary btn-block">Mulai Konsultasi</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/konsultasi/kategori.blade.php ENDPATH**/ ?>