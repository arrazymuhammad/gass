

<?php $__env->startSection('content'); ?>
<div id="content-page" class="content-page">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						Table Kategori
						<a href="" class="btn btn-primary float-right">Tambah Data</a>
					</div>
					<div class="card-body">
						<table class="table table-bordered">
							<thead>
								<th>No</th>
								<th>Aksi</th>
								<th>Nama</th>
								<th>Photo</th>
							</thead>
							<tbody>
								<?php $__currentLoopData = $list_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td></td>
									<td><?php echo e($kategori->nama); ?></td>
									<td><img src="<?php echo e(url($kategori->photo)); ?>" alt=""></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/kategori-praktisi/index.blade.php ENDPATH**/ ?>