<div class="chat-sidebar-channel scroller mt-4 pl-3">
	<h5 class=""><a href="<?php echo e(url('konsultasi')); ?>" class="btn btn-primary btn-block">Daftar Praktisi</a></h5>
	<ul class="iq-chat-ui nav flex-column nav-pills">
		<?php $__currentLoopData = $list_chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
			<a href="<?php echo e(url('konsultasi/chat', $cl->chatfriend->uuid)); ?>">
				<div class="d-flex align-items-center">
					<div class="avatar mr-2">
						<img src="<?php echo e(url("assets")); ?>/images/user/05.jpg" alt="chatuserimage" class="avatar-50 ">
						<span class="avatar-status"><i class="ri-checkbox-blank-circle-fill text-success"></i></span>
					</div>
					<div class="chat-sidebar-name">
						<h6 class="mb-0"><?php echo e($cl->chatfriend->fullname); ?></h6>
						<span></span>
					</div>
				</div>
			</a>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/konsultasi/chat/chat-list.blade.php ENDPATH**/ ?>