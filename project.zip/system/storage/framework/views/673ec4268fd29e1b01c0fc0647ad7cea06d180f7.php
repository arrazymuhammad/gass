

<?php $__env->startSection('content'); ?>
<div id="content-page" class="content-page">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="iq-card">
					<div class="iq-card-body chat-page p-0">
						<div class="chat-data-block">
							<div class="row">
								<div class="col-lg-3 chat-data-left scroller">
									<?php echo $__env->make('konsultasi.chat.chat-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php echo $__env->make('konsultasi.chat.chat-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
								<?php echo $__env->make('konsultasi.chat.chat-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/konsultasi/chat.blade.php ENDPATH**/ ?>