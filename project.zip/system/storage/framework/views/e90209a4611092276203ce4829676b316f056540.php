<?php
   function isActive($route){
      return request()->is($route) ? 'active' : '';
   }
?>

<div class="iq-sidebar">
   <div id="sidebar-scrollbar">
      <nav class="iq-sidebar-menu">
         <ul id="iq-sidebar-toggle" class="iq-menu">
            <li class="<?php echo e(isActive('newsfeed')); ?>">
               <a href="<?php echo e(url("newsfeed")); ?>" class="iq-waves-effect"><i class="las la-newspaper"></i><span>Newsfeed</span></a>
            </li>
            <li class="<?php echo e(isActive('konsultasi*')); ?>">
               <a href="<?php echo e(url("konsultasi/chat")); ?>" class="iq-waves-effect"><i class="las la-tasks"></i><span>Konsultasi</span></a>
            </li>
            <li class="<?php echo e(isActive('pengingat')); ?>">
               <a href="<?php echo e(url("pengingat")); ?>" class="iq-waves-effect"><i class="las la-bell"></i><span>Pengingat</span></a>
            </li>
            <li class="<?php echo e(isActive('events')); ?>">
               <a href="<?php echo e(url("events")); ?>" class="iq-waves-effect"><i class="las la-calendar"></i><span>Events</span></a>
            </li>
         </ul>
      </nav>
      <div class="p-3"></div>
   </div>
</div><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/template/section/sidebar.blade.php ENDPATH**/ ?>