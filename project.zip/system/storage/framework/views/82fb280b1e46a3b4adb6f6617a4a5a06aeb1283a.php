<?php $__currentLoopData = $list_feed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-12">
	<div class="iq-card iq-card-block iq-card-stretch iq-card-height">
		<div class="iq-card-body">
			<div class="user-post-data">
				<div class="d-flex flex-wrap">
					<div class="media-support-user-img mr-3">
						<img class="rounded-circle img-fluid" src="<?php echo e(url($feed->user->photo)); ?>" alt="">
					</div>
					<div class="media-support-info mt-2">
						<h5 class="mb-0 d-inline-block"><a href="#" class=""><?php echo e($feed->user->fullname); ?></a></h5>
						<p class="mb-0 d-inline-block">Add New Post</p>
						<p class="mb-0 text-primary"><?php echo e($feed->created_at->diffForHumans()); ?></p>
					</div>
				</div>
			</div>
			<div class="mt-3">
				<p>
					<?php echo e(nl2br($feed->content)); ?>

				</p>
			</div>
			<?php if($feed->image): ?>
			<div class="user-post">
				<div class="d-flex">
					<div class="col-md-12">
						<img src="<?php echo e(url($feed->image)); ?>" alt="post-image" class="img-fluid rounded w-100"></a>
					</div>
				</div>
			</div>
			<?php endif; ?>
			<div class="comment-area mt-3">
				<hr>
				<ul class="post-comments p-0 m-0">
					<?php $__currentLoopData = $feed->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="mb-2">
                        <div class="d-flex flex-wrap">
                            <div class="user-img">
                                <img src="<?php echo e(url($comment->post->user->photo)); ?>" alt="userimg" class="avatar-35 rounded-circle img-fluid">
                            </div>
                            <div class="comment-data-block ml-3">
                                <h6><?php echo e($comment->post->user->fullname); ?></h6>
                                <p class="mb-0"><?php echo e($comment->content); ?></p>
                                <div class="d-flex flex-wrap align-items-center comment-activity">
                                    <span><?php echo e($comment->created_at->diffForHumans()); ?></span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				<form class="comment-text comment-form d-flex align-items-center mt-3" data-post-id="<?php echo e($feed->uuid); ?>">
					<input type="text" name="content" class="form-control rounded">
					<div class="comment-attagement d-flex">
						<button class="btn btn-primary">Comment</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('script'); ?>
	<script>
		$(".comment-form").on("submit", function(e){
			e.preventDefault()
			post_id = $(this).data('postId')

			data = []
			$(this).serializeArray().forEach(function(item){
				data[item['name']] = item['value']
			})
			comment_list = $(this).prev()
			$.post(`comment/${post_id}`, $(this).serializeArray()).done(function(item){
				$(comment_list).html(item)
			})
			$(this).find('input').val("")
		})
	</script>
<?php $__env->stopPush(); ?><?php /**PATH F:\Kuliah\S2\UGM 2020\Semester 1\SOFTWARE DEVELOPMENT\2020-12-02 Week 10\project\system\resources\views/dashboard/post/list.blade.php ENDPATH**/ ?>