<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class KategoriPraktisi extends Model
{
	protected $table = 'kategori_praktisi';
}
